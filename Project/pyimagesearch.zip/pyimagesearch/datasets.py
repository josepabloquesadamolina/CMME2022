# import the necessary packages

import numpy as np
import cv2
import os
from skimage import io

def load_RVE_labels_displ(inputPath,L):
	l=str(L[0])
	cols = ["E1_Uniform_Strain_BCs"]
	df = pd.read_csv(inputPath+'/Labels-displacement-'+l+'x'+l+'.csv', sep=",", header=None, names=cols)
	# return the data frame with labels
	return df


def load_RVE_original_images(inputPath,L,res,N):
	l=str(L[0])
	os.chdir(inputPath+'/Dataset Original '+l+'x'+l )
	
	images = []
	for j in range(0,len(L)):
		str1='./rve-'+str(L[j])+'x'+str(L[j])+'-reg2-'
		for i in range(1,N+1):			
			try:
				image=io.imread('rve-'+str(L[j])+'x'+str(L[j])+'-reg2-'+str(i)+'-1.jpg')
				image = cv2.resize(image, (res,res))
				images.append(image)
			except OSError:
				print ('Warning: Image ' +  str1+str(i)+ ' not found')
	return np.array(images) # return set of images

